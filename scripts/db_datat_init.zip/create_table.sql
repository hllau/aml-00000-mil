﻿CREATE TABLE ACCRUAL_AIRPORT_PAIR 
   (	FKX_O_AIRPORT_CODE VARCHAR(4) NOT NULL , 
	FKX_D_AIRPORT_CODE VARCHAR(4) NOT NULL , 
	MARKETING_MILEAGE INT(9), 
	FKX1_CARRIERCODE VARCHAR(3) NOT NULL , 
	FLT_LEG_TYPE_CODE VARCHAR(1), 
	INACTIVE_INDICATOR VARCHAR(1), 
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL , 
	 CONSTRAINT PK_ACCRUAL_AIRPORT_PAIR PRIMARY KEY (FKX_O_AIRPORT_CODE, FKX_D_AIRPORT_CODE, FKX1_CARRIERCODE)
  
   );
 

  CREATE INDEX IDX_ACCRUAL_AIRPORT_PAIR_1 ON ACCRUAL_AIRPORT_PAIR (FKX1_CARRIERCODE, FKX_O_AIRPORT_CODE, FKX_D_AIRPORT_CODE) ;
 
 
   CREATE TABLE ACCRUAL_RATE 
   (	CODE VARCHAR(1) NOT NULL , 
	DESCRIPT VARCHAR(25) NOT NULL , 
	PERCENTAGE DOUBLE(4,3) NOT NULL 
   ) ;
 
 

  CREATE TABLE AIRPORT 
   (	AIRPORT_CODE VARCHAR(4) NOT NULL , 
	AIRPORT_NAME VARCHAR(35), 
	FKX_MAIN_CITY_CODE VARCHAR(6), 
	LAST_UPDT_DATE DATETIME, 
	LAST_UPDT_TIME DATETIME
   )  ;
 

  CREATE INDEX I_AIRPORT_1 ON AIRPORT (AIRPORT_CODE) ;
 

  CREATE TABLE AWARD_CLASS 
   (	AWARD_CODE VARCHAR(6) NOT NULL , 
	TICKET_UPGRADE VARCHAR(18) NOT NULL , 
	AWARD_CLASS VARCHAR(32) NOT NULL 
   )  ;
 
 
  CREATE TABLE AWARD_EXCLUDE 
   (	START_DATE DATETIME NOT NULL , 
	END_DATE DATETIME NOT NULL , 
	AWARD VARCHAR(12) NOT NULL 
   ) ;
  


  CREATE TABLE AWARD_TYPE 
   (	CODE VARCHAR(6) NOT NULL , 
	SHORT_DESC VARCHAR(62) NOT NULL , 
	FK2_RT_OW_IND_CODE VARCHAR(4), 
	FK1_MRCH_CLAS_CODE INT(2), 
	FK3_REDEMP_CLS_CD VARCHAR(1)
   )  ;
      

                                                                                                                                   
  CREATE TABLE AWARD_PACKAGE                                                                                           
   (	FK1_CARRIER_CODE VARCHAR(3) NOT NULL ,                                                                         
	FK2_M_AND_A_CODE VARCHAR(6) NOT NULL ,                                                                             
	MIXED_CARRIER_FLAG VARCHAR(1),                                                                                           
	FK1_PACKAGE_CODE VARCHAR(6) NOT NULL ,                                                                             
	FK1_AWARD_PGM_CODE VARCHAR(1) NOT NULL ,                                                                           
	AWARD_VALUE INT(7) NOT NULL ,                                                                                       
	MINIMUM_DISTANCE INT(7) NOT NULL ,                                                                                  
	MAXIMUM_DISTANCE INT(7) NOT NULL ,                                                                                  
	START_DATE DATETIME NOT NULL ,                                                                                               
	END_DATE DATETIME NOT NULL ,                                                                                                 
	MODIFIED_DATE DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL ,                                                                            
	 CONSTRAINT PK_AWARD_PACKAGE PRIMARY KEY (FK1_CARRIER_CODE, FK2_M_AND_A_CODE, FK1_PACKAGE_CODE, START_DATE, END_DATE)
                                                                                                
   ) ;                                                                                                     
                                                                                                                                   
                                                                                                                                   
  CREATE INDEX IDX_AWARD_PACKAGE_1 ON AWARD_PACKAGE (FK2_M_AND_A_CODE, FK1_CARRIER_CODE)   ;            
                 
  
  CREATE TABLE CITY 
   (	IATA_CODE VARCHAR(4), 
	LOCATION_NAME VARCHAR(45) NOT NULL , 
	COUNTRY_SELECTED VARCHAR(3)
   ) ;
 

  CREATE INDEX I_CITY_1 ON CITY (IATA_CODE) ;
  
 

  CREATE TABLE CLASS_GROUP 
   (	START_DATE DATETIME NOT NULL , 
	END_DATE DATETIME NOT NULL , 
	FK2_MIL_CLAS_CODE VARCHAR(1) NOT NULL , 
	FK1_BOOK_CLAS_CODE VARCHAR(2) NOT NULL , 
	FK1_CARRIER_CODE VARCHAR(3) NOT NULL 
   )       ;                                   
  
    CREATE TABLE CARRIER 
   (	CARRIER_CODE VARCHAR(3) NOT NULL , 
	CARRIER_NUMBER INT(3), 
	AIRLINE_DESIGNATOR VARCHAR(2), 
	CARRIER_NAME VARCHAR(80) NOT NULL , 
	LAST_UPDT_DATE DATETIME, 
	LAST_UPDT_TIME DATETIME, 
	PURGE_DATE DATETIME, 
	FK1_CARRIER_CODE VARCHAR(3), 
	DISALLOW_OPEN_JAW VARCHAR(1) DEFAULT 'N' NOT NULL , 
	DISALLOW_STOPOVER VARCHAR(1) DEFAULT 'N' NOT NULL , 
	DISALLOW_TRANSFER VARCHAR(1) DEFAULT 'N' NOT NULL 
   ) ;
 
 
  CREATE TABLE CARRIER_ITEM 
   (	START_DATE DATETIME NOT NULL , 
	END_DATE DATETIME NOT NULL , 
	MIXED_CARRIER_FLAG VARCHAR(1), 
	FK1_CARRIER_CODE VARCHAR(3) NOT NULL , 
	FK2_M_AND_A_CODE VARCHAR(6) NOT NULL , 
	FK3_AWARD_PGM_CODE VARCHAR(4) NOT NULL , 
	FK3_AWARD_PGM_TYPE VARCHAR(25) NOT NULL 
   ) ;
 
 
  CREATE TABLE PACKAGE_ITEM 
   (	FK2_PACKAGE_CODE VARCHAR(6) NOT NULL , 
	FK1_M_AND_A_CODE VARCHAR(6) NOT NULL 
   ) ;
                                                                          
  CREATE TABLE PROGRAM_PACKAGE                              
   (	PACKAGE_TYPE VARCHAR(15) NOT NULL ,                 
	AWARD_VALUE INT(7),                                            
	START_DT DATETIME NOT NULL ,                                      
	END_DT DATETIME NOT NULL ,                                        
	FK1_PACKAGE_CODE VARCHAR(6),                                  
	FK2_PP_AAZ_ID VARCHAR(3)                                      
   )     ;                     
  
                                                                                          
  CREATE TABLE PROGRAM_ZONE                                 
   (	IDENTIFIER VARCHAR(3) NOT NULL ,                    
	DESCRIPT VARCHAR(40) NOT NULL ,                         
	START_DATE DATETIME NOT NULL ,                                    
	END_DATE DATETIME NOT NULL ,                                      
	MAXIMUM_DISTANCE INT(7) NOT NULL ,                       
	MINIMUM_DISTANCE INT(7) NOT NULL ,                       
	FK1_AWARD_PGM_CODE VARCHAR(4),                                
	FK1_AWARD_PGM_TYPE VARCHAR(25)                                
   )  ;                                      
                                                        
  CREATE TABLE SECTOR_ACCRUAL 
   (	FKX_O_AIRPORT_CODE VARCHAR(4) NOT NULL , 
	FKX_D_AIRPORT_CODE VARCHAR(4) NOT NULL , 
	MARKETING_MILEAGE INT(9) NOT NULL , 
	LAST_UPDT_DATE DATETIME, 
	LAST_UPDT_TIME DATETIME, 
	FKX1_CARRIERCODE VARCHAR(3) NOT NULL , 
	FLT_LEG_TYPE_CODE VARCHAR(1) NOT NULL , 
	FLIGHT_TYPE_IND VARCHAR(2)
   )   ;                                                    
                                                                                                                                                   
  CREATE TABLE SECTOR_REDEMPTION                               
   (	FKX_O_AIRPORT_CODE VARCHAR(4) NOT NULL ,               
	FKX_D_AIRPORT_CODE VARCHAR(4) NOT NULL ,                   
	MARKETING_MILEAGE INT(9) NOT NULL ,                         
	LAST_UPDT_DATE DATETIME,                                                   
	LAST_UPDT_TIME DATETIME,                                                   
	FKX1_CARRIERCODE VARCHAR(3) NOT NULL ,                     
	FLT_LEG_TYPE_CODE VARCHAR(1) NOT NULL ,                    
	FLIGHT_TYPE_IND VARCHAR(2)                                       
   )    ;                                         
                                       
  CREATE TABLE TUTPARM 
   (	PARAM_NAME VARCHAR(16) NOT NULL , 
	PARAM_TYPE VARCHAR(1) NOT NULL , 
	PARAM_LENGTH INT(2) NOT NULL , 
	DECIMAL_PLACES INT(2), 
	PARAM_VALUE VARCHAR(40) NOT NULL , 
	DESCRIPT VARCHAR(250) NOT NULL , 
	USER_ID VARCHAR(8) NOT NULL , 
	LAST_UPDT_TIME DATETIME NOT NULL , 
	LAST_UPDT_DATE DATETIME NOT NULL , 
	 CONSTRAINT IUTPARM0 PRIMARY KEY (PARAM_NAME)
 
   ) ;


  CREATE TABLE ZONE_EXCLUDE 
   (	START_DATE DATETIME NOT NULL , 
	END_DATE DATETIME NOT NULL , 
	ZONE VARCHAR(6) NOT NULL 
   );
 
                                                                             